<?php return array (
  'commercial‌-bill' => 'App\\Http\\Livewire\\Commercial‌Bill',
  'household-bill' => 'App\\Http\\Livewire\\HouseholdBill',
);