<a href="/">
    <img src="<?php echo e(asset('/img/logo.png')); ?>" alt="">
</a>
<?php /**PATH D:\projects\laravel\electric-bill\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>