<div>
  <img style="width: 50px" src="<?php echo e(asset('/img/logo.png')); ?>" alt="">
</div><?php /**PATH D:\projects\laravel\electric-bill\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>