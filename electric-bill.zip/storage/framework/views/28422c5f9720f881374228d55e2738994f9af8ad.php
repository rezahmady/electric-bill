<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.field-wrapper','data' => ['id' => $getId(),'label' => $getLabel(),'helperText' => $getHelperText(),'hint' => $getHint(),'required' => $isRequired(),'statePath' => $getStatePath()]]); ?>
<?php $component->withName('forms::field-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getId()),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getLabel()),'helper-text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHelperText()),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHint()),'required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isRequired()),'state-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getStatePath())]); ?>
    <?php if (! ($isSearchable())): ?>
        <select
            <?php echo $isAutofocused() ? 'autofocus' : null; ?>

            <?php echo $isDisabled() ? 'disabled' : null; ?>

            id="<?php echo e($getId()); ?>"
            <?php echo $isRequired() ? 'required' : null; ?>

            <?php echo e($applyStateBindingModifiers('wire:model')); ?>="<?php echo e($getStatePath()); ?>"
            <?php echo e($attributes->merge($getExtraAttributes())->class([
                'block w-full h-10 transition duration-75 rounded-lg shadow-sm focus:border-primary-600 focus:ring-1 focus:ring-inset focus:ring-primary-600',
                'border-gray-300' => ! $errors->has($getStatePath()),
                'border-danger-600 ring-danger-600' => $errors->has($getStatePath()),
            ])); ?>

        >
            <option value="" <?php echo $isRequired() ? 'disabled' : ''; ?>></option>

            <?php $__currentLoopData = $getOptions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($value); ?>">
                    <?php echo e($label); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    <?php else: ?>
        <div
            x-data="selectFormComponent({
                getOptionLabelUsing: async (value) => {
                    return await $wire.getSelectOptionLabel('<?php echo e($getStatePath()); ?>')
                },
                getSearchResultsUsing: async (query) => {
                    return await $wire.getSelectSearchResults('<?php echo e($getStatePath()); ?>', query)
                },
                isAutofocused: <?php echo e($isAutofocused() ? 'true' : 'false'); ?>,
                options: <?php echo e(json_encode($getOptions())); ?>,
                state: $wire.<?php echo e($applyStateBindingModifiers('entangle(\'' . $getStatePath() . '\')')); ?>,
            })"
            x-on:click.away="closeListbox()"
            x-on:blur="closeListbox()"
            x-on:keydown.escape.stop="closeListbox()"
            <?php echo ($id = $getId()) ? "id=\"{$id}\"" : null; ?>

            class="relative"
            <?php echo e($attributes->merge($getExtraAttributes())); ?>

        >
            <div
                <?php if (! ($isDisabled())): ?>
                    x-ref="button"
                    x-on:click="toggleListboxVisibility()"
                    x-on:keydown.enter.stop.prevent="isOpen ? selectOption() : openListbox()"
                    x-on:keydown.space="if (! isOpen) openListbox()"
                    x-on:keydown.backspace="if (! search) clearState()"
                    x-on:keydown.clear="if (! search) clearState()"
                    x-on:keydown.delete="if (! search) clearState()"
                    x-bind:aria-expanded="isOpen"
                    aria-haspopup="listbox"
                    tabindex="1"
                <?php endif; ?>
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'relative flex items-center h-10 pl-3 pr-10 border overflow-hidden transition duration-75 rounded-lg shadow-sm focus-within:border-primary-600 focus-within:ring-1 focus-within:ring-inset focus-within:ring-primary-600 focus:outline-none',
                    'border-gray-300' => ! $errors->has($getStatePath()),
                    'border-danger-600 ring-danger-600' => $errors->has($getStatePath()),
                ]) ?>"
            >
                <span
                    x-show="! isOpen"
                    x-text="label ?? '<?php echo e($getPlaceholder()); ?>'"
                    class="absolute w-full bg-white"
                    x-bind:class="{
                        'text-gray-400': label === null,
                    }"
                ></span>

                <?php if (! ($isDisabled())): ?>
                    <input
                        x-ref="search"
                        x-model.debounce.500="search"
                        x-on:keydown.enter.stop.prevent="selectOption()"
                        x-on:keydown.arrow-up.stop.prevent="focusPreviousOption()"
                        x-on:keydown.arrow-down.stop.prevent="focusNextOption()"
                        type="text"
                        autocomplete="off"
                        class="w-full my-1 p-0 border-0 focus:ring-0 focus:outline-none"
                    />

                    <span class="absolute inset-y-0 right-0 flex items-center pr-2 pointer-events-none">
                        <svg x-show="! isLoading" x-cloak class="w-5 h-5"xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                            <path stroke="#6B7280" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M6 8l4 4 4-4" />
                        </svg>

                        <svg x-show="isLoading" class="w-5 h-5 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 50 50" fill="currentColor">
                            <path d="M6.306 28.014c1.72 10.174 11.362 17.027 21.536 15.307C38.016 41.6 44.87 31.958 43.15 21.784l-4.011.678c1.345 7.958-4.015 15.502-11.974 16.847-7.959 1.346-15.501-4.014-16.847-11.973l-4.011.678z" />

                            <animateTransform attributeType="xml" attributeName="transform" type="rotate" from="0 25 25" to="360 25 25" dur=".7s" repeatCount="indefinite" /></path>
                        </svg>
                    </span>
                <?php endif; ?>
            </div>

            <?php if (! ($isDisabled())): ?>
                <div
                    x-ref="listbox"
                    x-show="isOpen"
                    x-transition:leave="transition ease-in duration-100"
                    x-transition:leave-start="opacity-100"
                    x-transition:leave-end="opacity-0"
                    role="listbox"
                    x-bind:aria-activedescendant="focusedOptionIndex ? '<?php echo e($getStatePath()); ?>' + 'Option' + focusedOptionIndex : null"
                    tabindex="-1"
                    x-cloak
                    class="absolute z-10 w-full my-1 bg-white border border-gray-300 rounded-lg shadow-sm focus:outline-none"
                >
                    <ul
                        x-ref="listboxOptionsList"
                        class="py-1 overflow-auto text-base leading-6 max-h-60 focus:outline-none"
                    >
                        <template x-for="(key, index) in Object.keys(options)" :key="key">
                            <li
                                x-bind:id="'<?php echo e($getName()); ?>' + 'Option' + focusedOptionIndex"
                                x-on:click="selectOption(index)"
                                x-on:mouseenter="focusedOptionIndex = index"
                                x-on:mouseleave="focusedOptionIndex = null"
                                role="option"
                                x-bind:aria-selected="focusedOptionIndex === index"
                                x-bind:class="{
                                    'text-white bg-primary-500': index === focusedOptionIndex,
                                    'text-gray-900': index !== focusedOptionIndex,
                                }"
                                class="relative py-2 pl-3 h-10 flex items-center text-gray-900 cursor-default select-none pr-9"
                            >
                                <span
                                    x-text="Object.values(options)[index]"
                                    x-bind:class="{
                                        'font-medium': index === focusedOptionIndex,
                                        'font-normal': index !== focusedOptionIndex,
                                    }"
                                    class="block font-normal truncate"
                                ></span>

                                <span
                                    x-show="key === state"
                                    x-bind:class="{
                                        'text-white': index === focusedOptionIndex,
                                        'text-primary-500': index !== focusedOptionIndex,
                                    }"
                                    class="absolute inset-y-0 right-0 flex items-center pr-4 text-primary-500"
                                >
                                    <svg class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor">
                                        <path fill-rule="evenodd"
                                              d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z"
                                              clip-rule="evenodd" />
                                    </svg>
                                </span>
                            </li>
                        </template>

                        <div
                            x-show="! Object.keys(options).length"
                            x-text="! search || isLoading ? '<?php echo e($getSearchPrompt()); ?>' : '<?php echo e($getNoSearchResultsMessage()); ?>'"
                            class="px-3 py-2 text-sm text-gray-900 cursor-default select-none"
                        ></div>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
    <?php endif; ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\projects\laravel\electric-bill\vendor\filament\forms\src\/../resources/views/components/select.blade.php ENDPATH**/ ?>