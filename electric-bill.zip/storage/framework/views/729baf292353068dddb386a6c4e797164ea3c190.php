<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.field-wrapper','data' => ['id' => $getId(),'label' => $getLabel(),'helperText' => $getHelperText(),'hint' => $getHint(),'required' => $isRequired(),'statePath' => $getStatePath()]]); ?>
<?php $component->withName('forms::field-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getId()),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getLabel()),'helper-text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHelperText()),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHint()),'required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isRequired()),'state-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getStatePath())]); ?>
    <div
        x-data="markdownEditorFormComponent({
            state: $wire.<?php echo e($applyStateBindingModifiers('entangle(\'' . $getStatePath() . '\')')); ?>,
            tab: '<?php echo e($isDisabled() ? 'preview' : 'edit'); ?>',
        })"
        x-cloak
        wire:ignore
    >
        <div class="space-y-2">
            <?php if (! ($isDisabled())): ?>
                <div
                    x-bind:class="{
                        'justify-end': tab === 'preview',
                        'justify-between': tab !== 'preview',
                    }"
                    class="flex items-stretch h-8"
                >
                    <markdown-toolbar
                        x-show="tab !== 'preview'"
                        for="<?php echo e($getId()); ?>"
                        class="flex items-stretch space-x-4 rtl:space-x-reverse focus:outline-none"
                    >
                        <?php if($hasToolbarButton(['bold', 'italic', 'strike'])): ?>
                            <div class="flex items-stretch space-x-1 rtl:space-x-reverse">
                                <?php if($hasToolbarButton('bold')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.bold')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.bold')).'','class' => 'text-base']); ?>
                                        <md-bold>
                                            <svg class="w-4" viewBox="0 0 16 16" version="1.1" aria-hidden="true"><path fill-rule="evenodd" d="M4 2a1 1 0 00-1 1v10a1 1 0 001 1h5.5a3.5 3.5 0 001.852-6.47A3.5 3.5 0 008.5 2H4zm4.5 5a1.5 1.5 0 100-3H5v3h3.5zM5 9v3h4.5a1.5 1.5 0 000-3H5z"></path></svg>
                                        </md-bold>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php if($hasToolbarButton('italic')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.italic')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.italic')).'','class' => 'text-base']); ?>
                                        <md-italic>
                                            <svg class="w-4" height="16" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path fill-rule="evenodd" d="M6 2.75A.75.75 0 016.75 2h6.5a.75.75 0 010 1.5h-2.505l-3.858 9H9.25a.75.75 0 010 1.5h-6.5a.75.75 0 010-1.5h2.505l3.858-9H6.75A.75.75 0 016 2.75z"></path></svg>
                                        </md-italic>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php if($hasToolbarButton('strike')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.strike')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.strike')).'','class' => 'text-base']); ?>
                                        <md-strikethrough>
                                            <svg class="w-4" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16"><path fill-rule="evenodd" d="M7.581 3.25c-2.036 0-2.778 1.082-2.778 1.786 0 .055.002.107.006.157a.75.75 0 01-1.496.114 3.56 3.56 0 01-.01-.271c0-1.832 1.75-3.286 4.278-3.286 1.418 0 2.721.58 3.514 1.093a.75.75 0 11-.814 1.26c-.64-.414-1.662-.853-2.7-.853zm3.474 5.25h3.195a.75.75 0 000-1.5H1.75a.75.75 0 000 1.5h6.018c.835.187 1.503.464 1.951.81.439.34.647.725.647 1.197 0 .428-.159.895-.594 1.267-.444.38-1.254.726-2.676.726-1.373 0-2.38-.493-2.86-.956a.75.75 0 00-1.042 1.079C3.992 13.393 5.39 14 7.096 14c1.652 0 2.852-.403 3.65-1.085a3.134 3.134 0 001.12-2.408 2.85 2.85 0 00-.811-2.007z"></path></svg>
                                        </md-strikethrough>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if($hasToolbarButton(['link', 'attachFiles', 'codeBlock'])): ?>
                            <div class="flex items-stretch space-x-1 rtl:space-x-reverse">
                                <?php if($hasToolbarButton('link')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.link')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.link')).'','class' => 'text-base']); ?>
                                        <md-link class="w-full h-full">
                                            <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('heroicon-o-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
                                        </md-link>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php if($hasToolbarButton('attachFiles')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.attach_files')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.attach_files')).'','class' => 'text-base']); ?>
                                        <md-image class="w-full h-full" x-ref="imageTrigger">
                                            <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('heroicon-o-photograph'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
                                        </md-image>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php if($hasToolbarButton('codeBlock')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.code_block')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.code_block')).'','class' => 'text-base']); ?>
                                        <md-code class="w-full h-full">
                                            <?php if (isset($component)) { $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e = $component; } ?>
<?php $component = $__env->getContainer()->make(BladeUI\Icons\Components\Svg::class, []); ?>
<?php $component->withName('heroicon-o-code'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e)): ?>
<?php $component = $__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e; ?>
<?php unset($__componentOriginalcd9972c8156dfa6e5fd36675ca7bf5f21b506e2e); ?>
<?php endif; ?>
                                        </md-code>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>

                        <?php if($hasToolbarButton(['bulletList', 'orderedList'])): ?>
                            <div class="flex items-stretch space-x-1 rtl:space-x-reverse">
                                <?php if($hasToolbarButton('bulletList')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.bullet_list')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.bullet_list')).'','class' => 'text-base']); ?>
                                        <md-unordered-list class="w-full h-full">
                                            <svg height="16" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path fill-rule="evenodd" d="M2 4a1 1 0 100-2 1 1 0 000 2zm3.75-1.5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zm0 5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zm0 5a.75.75 0 000 1.5h8.5a.75.75 0 000-1.5h-8.5zM3 8a1 1 0 11-2 0 1 1 0 012 0zm-1 6a1 1 0 100-2 1 1 0 000 2z"></path></svg>
                                        </md-unordered-list>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>

                                <?php if($hasToolbarButton('orderedList')): ?>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.markdown-editor.toolbar-button','data' => ['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.ordered_list')).'','class' => 'text-base']]); ?>
<?php $component->withName('forms::markdown-editor.toolbar-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['title' => ''.e(__('forms::components.markdown_editor.toolbar_buttons.ordered_list')).'','class' => 'text-base']); ?>
                                        <md-ordered-list class="w-full h-full">
                                            <svg height="16" viewBox="0 0 16 16" version="1.1" width="16" aria-hidden="true"><path fill-rule="evenodd" d="M2.003 2.5a.5.5 0 00-.723-.447l-1.003.5a.5.5 0 00.446.895l.28-.14V6H.5a.5.5 0 000 1h2.006a.5.5 0 100-1h-.503V2.5zM5 3.25a.75.75 0 01.75-.75h8.5a.75.75 0 010 1.5h-8.5A.75.75 0 015 3.25zm0 5a.75.75 0 01.75-.75h8.5a.75.75 0 010 1.5h-8.5A.75.75 0 015 8.25zm0 5a.75.75 0 01.75-.75h8.5a.75.75 0 010 1.5h-8.5a.75.75 0 01-.75-.75zM.924 10.32l.003-.004a.851.851 0 01.144-.153A.66.66 0 011.5 10c.195 0 .306.068.374.146a.57.57 0 01.128.376c0 .453-.269.682-.8 1.078l-.035.025C.692 11.98 0 12.495 0 13.5a.5.5 0 00.5.5h2.003a.5.5 0 000-1H1.146c.132-.197.351-.372.654-.597l.047-.035c.47-.35 1.156-.858 1.156-1.845 0-.365-.118-.744-.377-1.038-.268-.303-.658-.484-1.126-.484-.48 0-.84.202-1.068.392a1.858 1.858 0 00-.348.384l-.007.011-.002.004-.001.002-.001.001a.5.5 0 00.851.525zM.5 10.055l-.427-.26.427.26z"></path></svg>
                                        </md-ordered-list>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    </markdown-toolbar>

                    <?php if($hasToolbarButton(['edit', 'preview']) && ! $isDisabled()): ?>
                        <div class="flex items-center space-x-4 rtl:space-x-reverse">
                            <?php if($hasToolbarButton('edit')): ?>
                                <button
                                    x-on:click.prevent="tab = 'edit'"
                                    x-bind:class="{ 'text-gray-400': tab !== 'edit' }"
                                    class="text-sm hover:underline"
                                >
                                    <?php echo e(__('forms::components.markdown_editor.toolbar_buttons.edit')); ?>

                                </button>
                            <?php endif; ?>

                            <?php if($hasToolbarButton('preview')): ?>
                                <button
                                    x-on:click.prevent="tab = 'preview'"
                                    x-bind:class="{ 'text-gray-400': tab !== 'preview' }"
                                    class="text-sm hover:underline"
                                >
                                    <?php echo e(__('forms::components.markdown_editor.toolbar_buttons.preview')); ?>

                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div x-show="tab === 'edit'" class="relative w-full h-full" style="min-height: 150px;">
                <file-attachment directory>
                    <textarea
                        <?php echo $isAutofocused() ? 'autofocus' : null; ?>

                        id="<?php echo e($getId()); ?>"
                        <?php echo ($placeholder = $getPlaceholder()) ? "placeholder=\"{$placeholder}\"" : null; ?>

                        <?php echo $isRequired() ? 'required' : null; ?>

                        <?php echo e($applyStateBindingModifiers('wire:model')); ?>="<?php echo e($getStatePath()); ?>"
                        x-on:input="resize"
                        x-on:keyup.enter="checkForAutoInsertion"
                        x-on:file-attachment-accepted.window="
                            attachment = $event.detail?.attachments?.[0]

                            if (! attachment || ! attachment.file) return

                            $wire.upload(`componentFileAttachments.<?php echo e($getStatePath()); ?>`, attachment.file, () => {
                                $wire.getComponentFileAttachmentUrl('<?php echo e($getStatePath()); ?>').then((url) => {
                                    if (! url) return

                                    $refs.imageTrigger.click()

                                    const urlStart = $refs.textarea.selectionStart + 2
                                    const urlEnd = urlStart + 3

                                    $refs.textarea.value = [
                                        $refs.textarea.value.substring(0, urlStart),
                                        url,
                                        $refs.textarea.value.substring(urlEnd)
                                    ].join('')

                                    $refs.textarea.selectionStart = urlStart - 2
                                    $refs.textarea.selectionEnd = urlStart - 2

                                    resize()
                                })
                            })
                        "
                        x-ref="textarea"
                        style="caret-color: black; color: transparent"
                        <?php echo e($attributes->merge($getExtraAttributes())->class([
                            'tracking-normal whitespace-pre-wrap overflow-y-hidden font-mono block absolute bg-transparent top-0 left-0 block z-1 w-full h-full min-h-full resize-none transition duration-75 rounded-lg shadow-sm focus:border-primary-500 focus:ring-1 focus:ring-inset focus:ring-primary-600',
                            'border-gray-300' => ! $errors->has($getStatePath()),
                            'border-danger-600 ring-danger-600' => $errors->has($getStatePath()),
                        ])); ?>

                    ></textarea>
                </file-attachment>

                <div
                    x-ref="overlay"
                    x-html="overlay"
                    style="padding: 8px 12px"
                    class="w-full h-full border border-transparent font-mono tracking-normal text-black break-words whitespace-pre-wrap"
                ></div>
            </div>

            <div class="block w-full h-full min-h-full px-6 py-4 border border-gray-300 rounded shadow-sm focus:border-primary-300" x-show="tab === 'preview'" style="min-height: 150px;">
                <div class="prose" x-html="preview"></div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\projects\laravel\electric-bill\vendor\filament\forms\src\/../resources/views/components/markdown-editor.blade.php ENDPATH**/ ?>