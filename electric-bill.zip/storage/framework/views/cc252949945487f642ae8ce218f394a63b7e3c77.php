<?php
    $sideLabelClasses = [
        'whitespace-nowrap transition group-focus-within:text-primary-500',
        'text-gray-400' => ! $errors->has($getStatePath()),
        'text-danger-400' => $errors->has($getStatePath()),
    ];
?>

<?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'forms::components.field-wrapper','data' => ['id' => $getId(),'label' => $getLabel(),'helperText' => $getHelperText(),'hint' => $getHint(),'required' => $isRequired(),'statePath' => $getStatePath()]]); ?>
<?php $component->withName('forms::field-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getId()),'label' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getLabel()),'helper-text' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHelperText()),'hint' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getHint()),'required' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($isRequired()),'state-path' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($getStatePath())]); ?>
    <div class="flex items-center space-x-1 group">
        <?php if($label = $getPrefixLabel()): ?>
            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses($sideLabelClasses) ?>">
                <?php echo e($label); ?>

            </span>
        <?php endif; ?>

        <div class="flex-1">
            <input
                <?php if (! ($hasMask())): ?>
                    <?php echo e($applyStateBindingModifiers('wire:model')); ?>="<?php echo e($getStatePath()); ?>"
                    type="<?php echo e($getType()); ?>"
                <?php else: ?>
                    x-data="textInputFormComponent({
                        <?php echo e($hasMask() ? "getMaskOptionsUsing: (IMask) => ({$getJsonMaskConfiguration()})," : null); ?>

                        state: $wire.<?php echo e($applyStateBindingModifiers('entangle(\'' . $getStatePath() . '\')')); ?>,
                    })"
                    type="text"
                    wire:ignore
                <?php endif; ?>
                <?php echo ($autocomplete = $getAutocomplete()) ? "autocomplete=\"{$autocomplete}\"" : null; ?>

                <?php echo $isAutofocused() ? 'autofocus' : null; ?>

                <?php echo $isDisabled() ? 'disabled' : null; ?>

                id="<?php echo e($getId()); ?>"
                <?php echo ($length = $getMaxLength()) ? "maxlength=\"{$length}\"" : null; ?>

                <?php echo ($value = $getMaxValue()) ? "max=\"{$value}\"" : null; ?>

                <?php echo ($length = $getMinLength()) ? "minlength=\"{$length}\"" : null; ?>

                <?php echo ($value = $getMinValue()) ? "min=\"{$value}\"" : null; ?>

                <?php echo ($placeholder = $getPlaceholder()) ? "placeholder=\"{$placeholder}\"" : null; ?>

                <?php echo $isRequired() ? 'required' : null; ?>

                <?php echo e($attributes->merge($getExtraAttributes())->class([
                    'block w-full h-10 transition duration-75 rounded-lg shadow-sm focus:border-primary-600 focus:ring-1 focus:ring-inset focus:ring-primary-600',
                    'border-gray-300' => ! $errors->has($getStatePath()),
                    'border-danger-600 ring-danger-600' => $errors->has($getStatePath()),
                ])); ?>

            />
        </div>

        <?php if($label = $getPostfixLabel()): ?>
            <span class="<?php echo \Illuminate\Support\Arr::toCssClasses($sideLabelClasses) ?>">
                <?php echo e($label); ?>

            </span>
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php /**PATH D:\projects\laravel\electric-bill\vendor\filament\forms\src\/../resources/views/components/text-input.blade.php ENDPATH**/ ?>