<?php $attributes = $attributes->exceptProps([
    'id',
    'label' => null,
    'labelPrefix' => null,
    'labelSrOnly' => false,
    'helperText' => null,
    'hint' => null,
    'required' => false,
    'statePath',
]); ?>
<?php foreach (array_filter(([
    'id',
    'label' => null,
    'labelPrefix' => null,
    'labelSrOnly' => false,
    'helperText' => null,
    'hint' => null,
    'required' => false,
    'statePath',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div <?php echo e($attributes); ?>>
    <?php if($label && $labelSrOnly): ?>
        <label for="<?php echo e($id); ?>" class="sr-only">
            <?php echo e($label); ?>

        </label>
    <?php endif; ?>

    <div class="space-y-2">
        <?php if(($label && ! $labelSrOnly) || $hint): ?>
            <div class="flex items-center justify-between space-x-2 rtl:space-x-reverse">
                <?php if($label && ! $labelSrOnly): ?>
                    <label
                        for="<?php echo e($id); ?>"
                        class="inline-flex items-center space-x-3"
                    >
                        <?php echo e($labelPrefix); ?>


                        <span class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'text-sm font-medium leading-4',
                            'text-gray-700' => ! $errors->has($statePath),
                            'text-danger-700' => $errors->has($statePath),
                        ]) ?>">
                            <?php echo e($label); ?>


                            <?php if($required): ?>
                                <sup class="font-medium text-danger-700">*</sup>
                            <?php endif; ?>
                        </span>
                    </label>
                <?php endif; ?>

                <?php if($hint): ?>
                    <div class="text-xs leading-tight text-gray-500">
                        <?php echo Str::of($hint)->markdown(); ?>

                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php echo e($slot); ?>


        <?php if($errors->has($statePath)): ?>
            <p class="text-sm text-danger-600">
                <?php echo e($errors->first($statePath)); ?>

            </p>
        <?php endif; ?>

        <?php if($helperText): ?>
            <div class="text-sm text-gray-600">
                <?php echo Str::of($helperText)->markdown(); ?>

            </div>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH D:\projects\laravel\electric-bill\vendor\filament\forms\src\/../resources/views/components/field-wrapper.blade.php ENDPATH**/ ?>