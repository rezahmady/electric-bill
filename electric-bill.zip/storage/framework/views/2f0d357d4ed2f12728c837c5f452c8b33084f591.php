<button
    type="button"
    <?php echo e($attributes->class(['border-gray-300 bg-white text-gray-800 text-xs py-1 px-3 cursor-pointer font-medium border rounded transition duration-200 shadow-sm hover:bg-gray-100 focus:ring-primary-200 focus:ring focus:ring-opacity-50'])); ?>

>
    <?php echo e($slot); ?>

</button><?php /**PATH D:\projects\laravel\electric-bill\vendor\filament\forms\src\/../resources/views/components/markdown-editor/toolbar-button.blade.php ENDPATH**/ ?>