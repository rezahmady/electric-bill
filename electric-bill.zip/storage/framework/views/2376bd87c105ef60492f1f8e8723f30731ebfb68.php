<div class="d-inline">
  <img class="inline-block p-1" style="width: 50px" src="<?php echo e(asset('/img/logo.png')); ?>" <?php echo e($attributes); ?> alt="">
  <span class="text-3xl">محاسبه‌ آسان صورت حساب مصرف برق</span>
</div>
<?php /**PATH D:\projects\laravel\electric-bill\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>